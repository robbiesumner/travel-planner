export interface PastTrip {
  id: string;
  destination: string;
  startDate: string;
  endDate: string;
}
