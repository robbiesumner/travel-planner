export interface Destination {
  id: string;
  name: string;
  imageUrl: string;
  score: number;
}
